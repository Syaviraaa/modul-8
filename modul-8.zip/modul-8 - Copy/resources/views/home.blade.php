@extends('layouts.app-home')

@section('content')
    @include('layouts.default')
@endsection
